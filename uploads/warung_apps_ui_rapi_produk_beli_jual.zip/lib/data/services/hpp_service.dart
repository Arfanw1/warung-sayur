import 'package:drift/drift.dart';
import '../db/app_db.dart';

class HppService {
  final AppDb db;
  HppService(this.db);

  /// Weighted average moving cost:
  /// stokBaru = stokLama + qtyBeli
  /// hppBaru  = (stokLama*hppLama + qtyBeli*hargaBeli) / stokBaru
  Future<void> applyPurchase({
    required String productId,
    required int qty,
    required int buyPrice,
    required DateTime date,
  }) async {
    if (qty <= 0 || buyPrice <= 0) {
      throw ArgumentError('Qty dan harga beli harus > 0');
    }

    await db.transaction(() async {
      final p = await (db.select(db.products)..where((t) => t.id.equals(productId))).getSingle();

      final stokLama = p.stockQty;
      final hppLama = p.hpp;

      final stokBaru = stokLama + qty;
      final totalCostLama = stokLama * hppLama;
      final totalCostBaru = qty * buyPrice;

      final hppBaru = stokBaru == 0 ? 0 : ((totalCostLama + totalCostBaru) / stokBaru).round();

      await db.into(db.purchases).insert(PurchasesCompanion.insert(
        productId: productId,
        qty: qty,
        buyPrice: buyPrice,
        date: date,
      ));

      await (db.update(db.products)..where((t) => t.id.equals(productId))).write(
        ProductsCompanion(
          stockQty: Value(stokBaru),
          hpp: Value(hppBaru),
        ),
      );
    });
  }

  /// Harga jual rekomendasi = HPP / (1 - margin)
  int recommendSellPrice({required int hpp, required int marginPct}) {
    final m = (marginPct.clamp(0, 90)) / 100.0;
    final denom = (1.0 - m);
    if (denom <= 0) return 0;
    return (hpp / denom).round();
  }
}
