import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app_db.dart';
import '../repos/products_repo.dart';
import '../repos/purchases_repo.dart';
import '../repos/sales_repo.dart';
import '../services/hpp_service.dart';

final dbProvider = Provider<AppDb>((ref) {
  final db = AppDb();
  ref.onDispose(db.close);
  return db;
});

final productsRepoProvider = Provider<ProductsRepo>((ref) {
  return ProductsRepo(ref.watch(dbProvider));
});

final salesRepoProvider = Provider<SalesRepo>((ref) {
  return SalesRepo(ref.watch(dbProvider));
});

final purchasesRepoProvider = Provider<PurchasesRepo>((ref) {
  return PurchasesRepo(ref.watch(dbProvider));
});

final hppServiceProvider = Provider<HppService>((ref) {
  return HppService(ref.watch(dbProvider));
});
