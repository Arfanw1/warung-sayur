import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:drift/drift.dart';

import '../../../core/format.dart';
import '../../../data/db/app_db.dart';
import '../../../data/db/providers.dart';
import '../../../data/repos/sales_repo.dart';
import '../../../data/services/hpp_service.dart';

class SaleForm extends ConsumerStatefulWidget {
  final int? duplicateFromSaleId;
  const SaleForm({super.key, this.duplicateFromSaleId});

  @override
  ConsumerState<SaleForm> createState() => _SaleFormState();
}

class _SaleFormState extends ConsumerState<SaleForm> {
  DateTime _date = DateTime.now();
  bool _isDebt = false;
  final _customer = TextEditingController();

  String? _selectedProductId;
  final _qty = TextEditingController();
  final _sellPrice = TextEditingController();

  final List<SaleDraftItem> _items = [];
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _loadDuplicateIfNeeded();
  }

  Future<void> _loadDuplicateIfNeeded() async {
    final saleId = widget.duplicateFromSaleId;
    if (saleId == null) return;
    final db = ref.read(dbProvider);

    final sale = await (db.select(db.sales)..where((t) => t.id.equals(saleId))).getSingle();
    final items = await (db.select(db.saleItems)..where((t) => t.saleId.equals(saleId))).get();

    setState(() {
      _date = DateTime.now();
      _isDebt = false;
      _customer.text = '';
      _items.clear();
    });

    // Map product info
    for (final it in items) {
      final p = await (db.select(db.products)..where((t) => t.id.equals(it.productId))).getSingle();
      _items.add(SaleDraftItem(
        productId: p.id,
        productName: p.name,
        unit: p.unit,
        qty: it.qty,
        sellPrice: it.sellPrice,
        hppAtSale: p.hpp, // pakai HPP sekarang untuk transaksi baru
      ));
    }
    setState(() {});
  }

  @override
  void dispose() {
    _customer.dispose();
    _qty.dispose();
    _sellPrice.dispose();
    super.dispose();
  }

  int get _total => _items.fold<int>(0, (p, e) => p + e.lineTotal);

  @override
  Widget build(BuildContext context) {
    final df = DateFormat('dd MMM yyyy');

    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 8,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Text('Transaksi Penjualan', style: Theme.of(context).textTheme.titleLarge),
          ),
          const SizedBox(height: 12),

          // Date + hutang toggle
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _pickDate,
                  icon: const Icon(Icons.calendar_today),
                  label: Text(df.format(_date)),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Hutang'),
                  value: _isDebt,
                  onChanged: (v) => setState(() => _isDebt = v),
                ),
              ),
            ],
          ),

          if (_isDebt) ...[
            const SizedBox(height: 8),
            TextField(
              controller: _customer,
              decoration: const InputDecoration(
                labelText: 'Nama pelanggan (opsional)',
                border: OutlineInputBorder(),
              ),
            ),
          ],

          const SizedBox(height: 12),
          _ProductPicker(
            selectedProductId: _selectedProductId,
            onChanged: (id, suggestedPrice) {
              setState(() {
                _selectedProductId = id;
                if (suggestedPrice != null && _sellPrice.text.trim().isEmpty) {
                  _sellPrice.text = suggestedPrice.toString();
                }
              });
            },
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _qty,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Qty',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _sellPrice,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Harga jual /unit',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _addItem,
              icon: const Icon(Icons.add),
              label: const Text('Tambah Item'),
            ),
          ),

          const SizedBox(height: 12),
          if (_items.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Text('Belum ada item. Tambahkan produk untuk transaksi ini.'),
            )
          else
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 260),
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: _items.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, i) {
                  final it = _items[i];
                  return ListTile(
                    title: Text('${it.productName} • ${it.qty} ${it.unit}'),
                    subtitle: Text('${rupiah(it.sellPrice)} /${it.unit} • HPP ${rupiah(it.hppAtSale)}'),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(rupiah(it.lineTotal), style: const TextStyle(fontWeight: FontWeight.w600)),
                        TextButton(
                          onPressed: () => setState(() => _items.removeAt(i)),
                          child: const Text('Hapus'),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),

          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Text('Total: ${rupiah(_total)}', style: Theme.of(context).textTheme.titleMedium),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton.icon(
                  onPressed: (_saving || _items.isEmpty) ? null : _save,
                  icon: _saving
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator())
                      : const Icon(Icons.check),
                  label: const Text('Simpan'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      firstDate: DateTime(now.year - 2),
      lastDate: DateTime(now.year + 2),
      initialDate: _date,
    );
    if (picked != null) setState(() => _date = DateTime(picked.year, picked.month, picked.day));
  }

  Future<void> _addItem() async {
    final pid = _selectedProductId;
    final qty = int.tryParse(_qty.text.trim()) ?? 0;
    final sellPrice = int.tryParse(_sellPrice.text.trim()) ?? 0;

    if (pid == null) {
      _snack('Pilih produk dulu');
      return;
    }
    if (qty <= 0) {
      _snack('Qty harus > 0');
      return;
    }
    if (sellPrice <= 0) {
      _snack('Harga jual harus > 0');
      return;
    }

    final db = ref.read(dbProvider);
    final p = await (db.select(db.products)..where((t) => t.id.equals(pid))).getSingle();

    if (p.stockQty < qty) {
      _snack('Stok tidak cukup. Stok ${p.stockQty}, jual $qty');
      return;
    }

    // snapshot HPP saat jual = HPP sekarang
    final item = SaleDraftItem(
      productId: p.id,
      productName: p.name,
      unit: p.unit,
      qty: qty,
      sellPrice: sellPrice,
      hppAtSale: p.hpp,
    );

    setState(() {
      _items.add(item);
      _qty.clear();
      _sellPrice.clear();
      _selectedProductId = null;
    });
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      await ref.read(salesRepoProvider).createSale(
            date: _date,
            items: List.of(_items),
            isDebt: _isDebt,
            customerName: _isDebt ? _customer.text : null,
          );
      if (!mounted) return;
      Navigator.pop(context);
    } catch (e) {
      _snack('$e');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }
}

class _ProductPicker extends ConsumerWidget {
  final String? selectedProductId;
  final void Function(String productId, int? suggestedPrice) onChanged;

  const _ProductPicker({
    required this.selectedProductId,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.watch(dbProvider);
    final hpp = ref.watch(hppServiceProvider);

    return StreamBuilder<List<Product>>(
      stream: (db.select(db.products)
            ..orderBy([(t) => OrderingTerm(expression: t.createdAt, mode: OrderingMode.desc)]))
          .watch(),
      builder: (context, snap) {
        final items = snap.data ?? const <Product>[];
        if (items.isEmpty) {
          return const Text('Belum ada produk. Tambah produk dulu di tab Produk.');
        }

        return DropdownButtonFormField<String>(
          value: selectedProductId,
          isExpanded: true,
          decoration: const InputDecoration(
            labelText: 'Pilih produk',
            border: OutlineInputBorder(),
          ),
          items: items.map((p) {
            final label = '${p.name} (Stok ${p.stockQty} ${p.unit})';
            return DropdownMenuItem(value: p.id, child: Text(label));
          }).toList(),
          onChanged: (v) {
            if (v == null) return;
            final p = items.firstWhere((x) => x.id == v);
            final suggested = p.activeSellPrice > 0
                ? p.activeSellPrice
                : hpp.recommendSellPrice(hpp: p.hpp, marginPct: p.marginPct);
            onChanged(v, suggested > 0 ? suggested : null);
          },
        );
      },
    );
  }
}