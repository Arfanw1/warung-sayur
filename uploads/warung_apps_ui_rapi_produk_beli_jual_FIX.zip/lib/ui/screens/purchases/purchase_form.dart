import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../data/db/providers.dart';
import '../../../data/db/app_db.dart';

class PurchaseForm extends ConsumerStatefulWidget {
  const PurchaseForm({super.key});

  @override
  ConsumerState<PurchaseForm> createState() => _PurchaseFormState();
}

class _PurchaseFormState extends ConsumerState<PurchaseForm> {
  Product? _selected;
  final _qty = TextEditingController();
  final _price = TextEditingController();
  DateTime _date = DateTime.now();
  bool _loading = false;

  @override
  void dispose() {
    _qty.dispose();
    _price.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final df = DateFormat('dd MMM yyyy');

    return FutureBuilder<List<Product>>(
      future: ref.read(productsRepoProvider).getAllOnce(),
      builder: (context, snap) {
        final products = snap.data ?? const <Product>[];

        return Padding(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 8,
            bottom: MediaQuery.of(context).viewInsets.bottom + 16,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Text('Tambah Pembelian', style: Theme.of(context).textTheme.titleLarge),
              ),
              const SizedBox(height: 12),

              DropdownButtonFormField<Product>(
                value: _selected,
                items: products
                    .map((p) => DropdownMenuItem<Product>(
                          value: p,
                          child: Text(p.name),
                        ))
                    .toList(),
                onChanged: (v) => setState(() => _selected = v),
                decoration: const InputDecoration(
                  labelText: 'Pilih produk',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),

              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _qty,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        labelText: _selected == null ? 'Qty' : 'Qty (${_selected!.unit})',
                        border: const OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextField(
                      controller: _price,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Harga beli / unit (Rp)',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: _pickDate,
                child: InputDecorator(
                  decoration: const InputDecoration(
                    labelText: 'Tanggal',
                    border: OutlineInputBorder(),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(df.format(_date)),
                      const Icon(Icons.calendar_today_outlined, size: 18),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 16),

              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _loading ? null : _save,
                  icon: _loading
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator())
                      : const Icon(Icons.save),
                  label: const Text('Simpan Pembelian'),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Catatan: pembelian otomatis menambah stok & update HPP rata-rata tertimbang.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      firstDate: DateTime(now.year - 2),
      lastDate: DateTime(now.year + 1),
      initialDate: _date,
    );
    if (picked != null) setState(() => _date = picked);
  }

  Future<void> _save() async {
    final p = _selected;
    if (p == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pilih produk dulu')));
      return;
    }

    final qty = int.tryParse(_qty.text.trim()) ?? 0;
    final price = int.tryParse(_price.text.trim()) ?? 0;

    if (qty <= 0 || price <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Qty & harga harus > 0')));
      return;
    }

    setState(() => _loading = true);
    try {
      await ref.read(hppServiceProvider).applyPurchase(
            productId: p.id,
            qty: qty,
            buyPrice: price,
            date: _date,
          );
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }
}
