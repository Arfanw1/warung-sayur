import 'dart:math';
import 'package:drift/drift.dart';
import '../db/app_db.dart';

class ProductsRepo {
  final AppDb db;
  ProductsRepo(this.db);

  Stream<List<Product>> watchAll() {
    return (db.select(db.products)
          ..orderBy([
            (t) => OrderingTerm(expression: t.createdAt, mode: OrderingMode.desc),
          ]))
        .watch();
  }

  Future<List<Product>> getAllOnce() {
    return (db.select(db.products)
          ..orderBy([
            (t) => OrderingTerm(expression: t.name, mode: OrderingMode.asc),
          ]))
        .get();
  }

  Future<void> upsert({
    String? id,
    required String name,
    required String unit,
    required int marginPct,
  }) async {
    final cleanName = name.trim();
    final cleanUnit = unit.trim();
    if (cleanName.isEmpty) throw ArgumentError('Nama produk wajib diisi');
    if (cleanUnit.isEmpty) throw ArgumentError('Satuan wajib diisi');
    if (marginPct < 0 || marginPct > 90) throw ArgumentError('Margin harus 0..90');

    final pid = id ?? _genId();

    await db.into(db.products).insertOnConflictUpdate(
          ProductsCompanion(
            id: Value(pid),
            name: Value(cleanName),
            unit: Value(cleanUnit),
            marginPct: Value(marginPct),
          ),
        );
  }

  Future<void> deleteById(String id) async {
    await (db.delete(db.products)..where((t) => t.id.equals(id))).go();
  }

  String _genId() {
    final r = Random();
    final ts = DateTime.now().microsecondsSinceEpoch;
    final rnd = r.nextInt(1 << 20);
    return 'P$ts$rnd';
  }
}
