import 'package:flutter/material.dart';

class SalesScreen extends StatelessWidget {
  const SalesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Penjualan')),
      body: const Center(
        child: Text('Placeholder: Penjualan + item + snapshot HPP'),
      ),
    );
  }
}
