import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../data/db/providers.dart';
import '../../../data/db/app_db.dart';

class ProductForm extends ConsumerStatefulWidget {
  final String? productId;
  const ProductForm({super.key, this.productId});

  @override
  ConsumerState<ProductForm> createState() => _ProductFormState();
}

class _ProductFormState extends ConsumerState<ProductForm> {
  final _name = TextEditingController();
  final _unit = TextEditingController();
  final _margin = TextEditingController(text: '20');

  bool _loading = false;
  Product? _existing;

  @override
  void initState() {
    super.initState();
    _loadIfEdit();
  }

  Future<void> _loadIfEdit() async {
    if (widget.productId == null) return;
    final db = ref.read(dbProvider);
    final p = await (db.select(db.products)
          ..where((t) => t.id.equals(widget.productId!)))
        .getSingle();
    setState(() => _existing = p);
    _name.text = p.name;
    _unit.text = p.unit;
    _margin.text = p.marginPct.toString();
  }

  @override
  void dispose() {
    _name.dispose();
    _unit.dispose();
    _margin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.productId != null;

    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 8,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              isEdit ? 'Edit Produk' : 'Tambah Produk',
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _name,
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(
              labelText: 'Nama produk',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _unit,
                  textInputAction: TextInputAction.next,
                  decoration: const InputDecoration(
                    labelText: 'Satuan (kg/ikat/pcs)',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              SizedBox(
                width: 120,
                child: TextField(
                  controller: _margin,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Margin %',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _loading ? null : _save,
              icon: _loading
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator())
                  : const Icon(Icons.save),
              label: Text(isEdit ? 'Simpan Perubahan' : 'Simpan Produk'),
            ),
          ),
          const SizedBox(height: 8),
          if (isEdit && _existing != null)
            SizedBox(
              width: double.infinity,
              child: TextButton.icon(
                onPressed: _loading ? null : _delete,
                icon: const Icon(Icons.delete, color: Colors.red),
                label: const Text('Hapus Produk', style: TextStyle(color: Colors.red)),
              ),
            ),
        ],
      ),
    );
  }

  Future<void> _save() async {
    final name = _name.text;
    final unit = _unit.text;
    final marginPct = int.tryParse(_margin.text.trim()) ?? -1;

    setState(() => _loading = true);
    try {
      await ref.read(productsRepoProvider).upsert(
            id: widget.productId,
            name: name,
            unit: unit,
            marginPct: marginPct,
          );
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _delete() async {
    final id = widget.productId!;
    final ok = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Hapus produk?'),
            content: const Text('Data produk akan dihapus dari daftar.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
              FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus')),
            ],
          ),
        ) ??
        false;

    if (!ok) return;

    setState(() => _loading = true);
    try {
      await ref.read(productsRepoProvider).deleteById(id);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }
}
