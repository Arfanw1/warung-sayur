import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'db/app_db.dart';
import 'services/hpp_service.dart';

final dbProvider = Provider<AppDb>((ref) {
  final db = AppDb();
  ref.onDispose(db.close);
  return db;
});

final hppServiceProvider = Provider<HppService>((ref) {
  final db = ref.watch(dbProvider);
  return HppService(db);
});
