import 'package:drift/drift.dart';
import '../db/app_db.dart';

class PurchaseRow {
  final Purchase purchase;
  final Product product;
  PurchaseRow(this.purchase, this.product);
}

class PurchasesRepo {
  final AppDb db;
  PurchasesRepo(this.db);

  Stream<List<PurchaseRow>> watchLatest({int limit = 200}) {
    final q = (db.select(db.purchases)
          ..orderBy([
            (t) => OrderingTerm(expression: t.date, mode: OrderingMode.desc),
            (t) => OrderingTerm(expression: t.id, mode: OrderingMode.desc),
          ])
          ..limit(limit));

    final joinQ = q.join([
      innerJoin(db.products, db.products.id.equalsExp(db.purchases.productId)),
    ]);

    return joinQ.watch().map((rows) {
      return rows.map((r) {
        final pur = r.readTable(db.purchases);
        final prod = r.readTable(db.products);
        return PurchaseRow(pur, prod);
      }).toList();
    });
  }

  Future<void> deleteById(int id) async {
    await (db.delete(db.purchases)..where((t) => t.id.equals(id))).go();
  }
}
