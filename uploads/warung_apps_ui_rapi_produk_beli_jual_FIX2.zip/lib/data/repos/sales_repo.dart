import 'package:drift/drift.dart';
import '../db/app_db.dart';

class SaleRow {
  final int id;
  final DateTime date;
  final int total;
  final bool isDebt;
  final String? customerName;
  final int itemCount;
  SaleRow({
    required this.id,
    required this.date,
    required this.total,
    required this.isDebt,
    required this.customerName,
    required this.itemCount,
  });
}

class SaleDraftItem {
  final String productId;
  final String productName;
  final String unit;
  final int qty;
  final int sellPrice;
  final int hppAtSale;

  const SaleDraftItem({
    required this.productId,
    required this.productName,
    required this.unit,
    required this.qty,
    required this.sellPrice,
    required this.hppAtSale,
  });

  int get lineTotal => qty * sellPrice;
  int get lineHpp => qty * hppAtSale;
}

class SalesRepo {
  final AppDb db;
  SalesRepo(this.db);

  Stream<List<SaleRow>> watchLatest({int limit = 300}) {
    final s = db.sales;
    final si = db.saleItems;

    final query = db.select(s)
      ..orderBy([(t) => OrderingTerm(expression: t.date, mode: OrderingMode.desc)])
      ..limit(limit);

    // itemCount via subquery per row (ok for small limits)
    return query.watch().asyncMap((sales) async {
      final rows = <SaleRow>[];
      for (final sale in sales) {
        final countExp = si.id.count();
        final countQ = db.selectOnly(si)
          ..addColumns([countExp])
          ..where(si.saleId.equals(sale.id));
        final countRes = await countQ.getSingle();
        final itemCount = countRes.read(countExp) ?? 0;

        rows.add(SaleRow(
          id: sale.id,
          date: sale.date,
          total: sale.total,
          isDebt: sale.isDebt,
          customerName: sale.customerName,
          itemCount: itemCount,
        ));
      }
      return rows;
    });
  }

  Future<void> createSale({
    required DateTime date,
    required List<SaleDraftItem> items,
    required bool isDebt,
    String? customerName,
  }) async {
    if (items.isEmpty) throw ArgumentError('Isi minimal 1 item');

    final total = items.fold<int>(0, (p, e) => p + e.lineTotal);

    await db.transaction(() async {
      // Validasi stok cukup & update stok
      for (final it in items) {
        final p = await (db.select(db.products)..where((t) => t.id.equals(it.productId))).getSingle();
        if (p.stockQty < it.qty) {
          throw StateError('Stok tidak cukup untuk ${it.productName}. Stok: ${p.stockQty}, jual: ${it.qty}');
        }
      }

      // Insert sale
      final saleId = await db.into(db.sales).insert(SalesCompanion.insert(
        date: date,
        total: Value(total),
        isDebt: Value(isDebt),
        customerName: Value(isDebt ? (customerName?.trim().isEmpty ?? true ? null : customerName!.trim()) : null),
      ));

      // Insert items + update product stock
      for (final it in items) {
        await db.into(db.saleItems).insert(SaleItemsCompanion.insert(
          saleId: saleId,
          productId: it.productId,
          qty: it.qty,
          sellPrice: it.sellPrice,
          hppAtSale: it.hppAtSale,
        ));

        // Decrement stok atomically
        await db.customUpdate(
          'UPDATE products SET stock_qty = stock_qty - ? WHERE id = ?',
          variables: [Variable.withInt(it.qty), Variable.withString(it.productId)],
          updates: {db.products},
        );
      }

      // Jika hutang, buat entry debt
      if (isDebt) {
        final cust = (customerName ?? '').trim();
        await db.into(db.debts).insert(DebtsCompanion.insert(
          customerName: cust.isEmpty ? 'Pelanggan' : cust,
          date: date,
          total: total,
          remaining: total,
          isClosed: const Value(false),
        ));
      }
    });
  }
}
