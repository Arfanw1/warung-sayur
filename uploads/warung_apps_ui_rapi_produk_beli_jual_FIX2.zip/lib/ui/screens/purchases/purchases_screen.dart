import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../data/db/providers.dart';
import '../../../data/repos/purchases_repo.dart';
import 'purchase_form.dart';

final purchasesStreamProvider = StreamProvider<List<PurchaseRow>>((ref) {
  return ref.watch(purchasesRepoProvider).watchLatest(limit: 300);
});

class PurchasesScreen extends ConsumerWidget {
  const PurchasesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final asyncRows = ref.watch(purchasesStreamProvider);
    final df = DateFormat('dd MMM yyyy');

    return Scaffold(
      appBar: AppBar(title: const Text('Pembelian')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openForm(context),
        icon: const Icon(Icons.add),
        label: const Text('Tambah'),
      ),
      body: asyncRows.when(
        data: (rows) {
          if (rows.isEmpty) {
            return const Center(
              child: Text('Belum ada pembelian.\nTap "Tambah" untuk catat belanja.'),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 96),
            itemCount: rows.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final r = rows[i];
              final total = r.purchase.qty * r.purchase.buyPrice;
              final subtitle =
                  '${df.format(r.purchase.date)} • Qty ${r.purchase.qty} ${r.product.unit} • Harga ${r.purchase.buyPrice}/unit • Total $total';

              return Dismissible(
                key: ValueKey(r.purchase.id),
                direction: DismissDirection.endToStart,
                background: Container(
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 16),
                  color: Colors.red.withValues(alpha: 0.15),
                  child: const Icon(Icons.delete, color: Colors.red),
                ),
                confirmDismiss: (_) async {
                  return await showDialog<bool>(
                        context: context,
                        builder: (ctx) => AlertDialog(
                          title: const Text('Hapus pembelian?'),
                          content: const Text(
                              'Catatan pembelian akan dihapus.\nCatatan: stok & HPP tidak otomatis dibalik pada versi ini.'),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
                            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus')),
                          ],
                        ),
                      ) ??
                      false;
                },
                onDismissed: (_) async {
                  await ref.read(purchasesRepoProvider).deleteById(r.purchase.id);
                },
                child: Card(
                  child: ListTile(
                    title: Text(r.product.name),
                    subtitle: Text(subtitle),
                    trailing: const Icon(Icons.receipt_long_outlined),
                  ),
                ),
              );
            },
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
      ),
    );
  }

  void _openForm(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (_) => const PurchaseForm(),
    );
  }
}
