import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../core/format.dart';
import '../../../data/db/providers.dart';
import '../../../data/repos/sales_repo.dart';
import 'sale_form.dart';

final salesStreamProvider = StreamProvider<List<SaleRow>>((ref) {
  return ref.watch(salesRepoProvider).watchLatest(limit: 300);
});

class SalesScreen extends ConsumerWidget {
  const SalesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final asyncRows = ref.watch(salesStreamProvider);
    final df = DateFormat('dd MMM yyyy');

    return Scaffold(
      appBar: AppBar(title: const Text('Penjualan')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openForm(context),
        icon: const Icon(Icons.add),
        label: const Text('Transaksi'),
      ),
      body: asyncRows.when(
        data: (rows) {
          if (rows.isEmpty) {
            return const Center(
              child: Text('Belum ada penjualan.\nTap "Transaksi" untuk mulai jual.'),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 96),
            itemCount: rows.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final r = rows[i];
              final title = rupiah(r.total);
              final subtitle = '${df.format(r.date)} • ${r.itemCount} item'
                  '${r.isDebt ? ' • Hutang' : ''}'
                  '${(r.customerName ?? '').isNotEmpty ? ' • ${r.customerName}' : ''}';

              return Card(
                child: ListTile(
                  title: Text(title),
                  subtitle: Text(subtitle),
                  leading: Icon(r.isDebt ? Icons.credit_card : Icons.receipt_long),
                  onTap: () => _openForm(context, duplicateFromSaleId: r.id),
                ),
              );
            },
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
      ),
    );
  }

  void _openForm(BuildContext context, {int? duplicateFromSaleId}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (_) => SaleForm(duplicateFromSaleId: duplicateFromSaleId),
    );
  }
}
