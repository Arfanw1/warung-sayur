import 'package:drift/drift.dart';

class Products extends Table {
  TextColumn get id => text()(); // uuid/string
  TextColumn get name => text()();
  TextColumn get unit => text()(); // kg/ikat/pcs (unit dasar)
  IntColumn get marginPct => integer().withDefault(const Constant(20))(); // 0..90
  IntColumn get activeSellPrice => integer().withDefault(const Constant(0))(); // rupiah per unit dasar
  IntColumn get stockQty => integer().withDefault(const Constant(0))(); // stok dalam unit dasar
  IntColumn get hpp => integer().withDefault(const Constant(0))(); // rupiah per unit dasar
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();

  @override
  Set<Column> get primaryKey => {id};
}

class Purchases extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get productId => text()();
  IntColumn get qty => integer()();
  IntColumn get buyPrice => integer()(); // rupiah per unit dasar
  DateTimeColumn get date => dateTime()();
}

class Sales extends Table {
  IntColumn get id => integer().autoIncrement()();
  DateTimeColumn get date => dateTime()();
  IntColumn get total => integer().withDefault(const Constant(0))();
  BoolColumn get isDebt => boolean().withDefault(const Constant(false))();
  TextColumn get customerName => text().nullable()();
}

class SaleItems extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get saleId => integer()();
  TextColumn get productId => text()();
  IntColumn get qty => integer()();
  IntColumn get sellPrice => integer()(); // rupiah per unit dasar
  IntColumn get hppAtSale => integer()(); // snapshot HPP saat jual
}

class Expenses extends Table {
  IntColumn get id => integer().autoIncrement()();
  DateTimeColumn get date => dateTime()();
  TextColumn get category => text()();
  IntColumn get amount => integer()();
  TextColumn get note => text().nullable()();
}

class Debts extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get customerName => text()();
  DateTimeColumn get date => dateTime()();
  IntColumn get total => integer()();
  IntColumn get remaining => integer()();
  BoolColumn get isClosed => boolean().withDefault(const Constant(false))();
}

class DebtPayments extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get debtId => integer()();
  DateTimeColumn get date => dateTime()();
  IntColumn get amount => integer()();
}
