import 'package:flutter/material.dart';

class PurchasesScreen extends StatelessWidget {
  const PurchasesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pembelian')),
      body: const Center(
        child: Text('Placeholder: Pembelian + update stok & HPP otomatis'),
      ),
    );
  }
}
