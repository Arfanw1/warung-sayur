import 'package:flutter/material.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Laporan')),
      body: const Center(
        child: Text('Placeholder: Laporan omzet, HPP, laba kotor/bersih, rekap produk'),
      ),
    );
  }
}
