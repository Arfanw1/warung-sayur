import 'package:flutter/material.dart';
import 'products/products_screen.dart';
import 'purchases/purchases_screen.dart';
import 'sales/sales_screen.dart';
import 'reports/reports_screen.dart';
import 'debts/debts_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int idx = 0;

  final screens = const [
    ProductsScreen(),
    PurchasesScreen(),
    SalesScreen(),
    ReportsScreen(),
    DebtsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: screens[idx]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: idx,
        onDestinationSelected: (v) => setState(() => idx = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'Produk'),
          NavigationDestination(icon: Icon(Icons.shopping_bag_outlined), label: 'Beli'),
          NavigationDestination(icon: Icon(Icons.point_of_sale_outlined), label: 'Jual'),
          NavigationDestination(icon: Icon(Icons.assessment_outlined), label: 'Laporan'),
          NavigationDestination(icon: Icon(Icons.credit_card_outlined), label: 'Hutang'),
        ],
      ),
    );
  }
}
